Sudarshan Beta for Windows
==========================

This beta package is a portable Windows build for authorized local defensive security analysis.

How to run:
1. Extract the ZIP.
2. Open the extracted folder.
3. Run Sudarshan.exe.

No GitHub account, private repository access, or GitHub token is required.

Qwen local AI:
- Qwen2.5-Coder 7B model weights are not bundled in this package.
- To enable local AI proposals, install Ollama separately and run:
  ollama pull qwen2.5-coder:7b
- Sudarshan uses the local ollama_qwen_small profile when the model is available.
- If Ollama or the model is unavailable, Sudarshan falls back to offline deterministic behavior.

Security note:
Python executable packaging hides source code from normal beta users, but it is not perfect IP protection.
Do not upload this ZIP together with source code, .env files, private keys, tokens, model weights, or training corpus data.
