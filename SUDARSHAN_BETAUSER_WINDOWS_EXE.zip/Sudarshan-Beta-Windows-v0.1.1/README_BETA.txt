Sudarshan Beta for Windows
==========================

This beta package is a portable Windows build for authorized local defensive security analysis.

How to run:
1. Extract the ZIP.
2. Open the extracted folder.
3. Run Sudarshan.exe.

No GitHub account, private repository access, or GitHub token is required.

Qwen local AI:
- Qwen model weights are not bundled in this package.
- Sudarshan is local-first. Your code stays on your machine. The selected local AI model runs through Ollama on localhost. Sudarshan does not upload your repository to our server.
- On first run, open http://127.0.0.1:8767/setup or use the setup screen opened by Sudarshan.
- Install Ollama separately from https://ollama.com/download if it is not installed.
- Choose the model that fits your hardware:
  0.5B = fastest, lowest quality
  1.5B = light
  3B = recommended for 16GB RAM
  7B = better quality, slower/heavier
  14B/32B = advanced/heavy
- Sudarshan can pull and test the selected model with Ollama, then saves the choice in app_data/settings/model_config.json.
- If Ollama or the model is unavailable, Sudarshan shows a clear message and keeps offline deterministic behavior.

Security note:
Python executable packaging hides source code from normal beta users, but it is not perfect IP protection.
Do not upload this ZIP together with source code, .env files, private keys, tokens, model weights, or training corpus data.
