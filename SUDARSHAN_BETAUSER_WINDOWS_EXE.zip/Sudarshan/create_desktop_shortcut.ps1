param(
  [string]$ExePath = "",
  [string]$ShortcutName = "Sudarshan Local Audit.lnk"
)

$ErrorActionPreference = "Stop"
$RepoRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $RepoRoot

if ([string]::IsNullOrWhiteSpace($ExePath)) {
  if (Test-Path -LiteralPath ".\dist\Sudarshan\Sudarshan.exe") {
    $ExePath = ".\dist\Sudarshan\Sudarshan.exe"
  } elseif (Test-Path -LiteralPath ".\Sudarshan.exe") {
    $ExePath = ".\Sudarshan.exe"
  } else {
    throw "Sudarshan.exe was not found. Pass -ExePath explicitly."
  }
}

$ResolvedExe = (Resolve-Path -LiteralPath $ExePath).Path
if (-not (Test-Path -LiteralPath $ResolvedExe)) {
  throw "Sudarshan.exe was not found at: $ExePath"
}

$Desktop = [Environment]::GetFolderPath("DesktopDirectory")
$ShortcutPath = Join-Path $Desktop $ShortcutName
$Shell = New-Object -ComObject WScript.Shell
$Shortcut = $Shell.CreateShortcut($ShortcutPath)
$Shortcut.TargetPath = $ResolvedExe
$Shortcut.WorkingDirectory = Split-Path -Parent $ResolvedExe
$Shortcut.Description = "Sudarshan Local Repo Security Audit"
$Shortcut.IconLocation = $ResolvedExe
$Shortcut.WindowStyle = 1
$Shortcut.Save()

[PSCustomObject]@{
  ShortcutPath = $ShortcutPath
  TargetPath = $ResolvedExe
}
